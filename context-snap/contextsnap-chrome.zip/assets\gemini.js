function e(){let e=[],t=Array.from(document.querySelectorAll(`user-query-content, user-query`)),n=Array.from(document.querySelectorAll(`model-response`));return[...t,...n].sort((e,t)=>e.compareDocumentPosition(t)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1).forEach(t=>{let n=t.tagName.toLowerCase().includes(`user-query`),r=``;n?r=t.querySelector(`p.query-text-line, .query-text, p`)?.textContent?.trim()||t.textContent?.trim()||``:(r=t.querySelector(`.response-content, div[class*="response-content"], .markdown`)?.textContent?.trim()||t.textContent?.trim()||``,r=r.replace(/^Show thinking\s*/i,``).trim()),r&&e.push({role:n?`user`:`assistant`,content:r})}),e}function t(e){return e.map(e=>`${e.role===`user`?`User`:`AI`}: ${e.content}`).join(`

`)}async function n(e,t){return(await(await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${e}`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({contents:[{parts:[{text:`You are a conversation summarizer. Given this AI chat history, create a concise but complete context summary to resume the conversation. Include: main topics, key decisions, and the last task being worked on. Keep it under 300 words.\n\n${t}`}]}]})})).json()).candidates?.[0]?.content?.parts?.[0]?.text||null}function r(e,t=!1){let n=document.getElementById(`contextsnap-toast`);n&&n.remove();let r=document.createElement(`div`);r.id=`contextsnap-toast`,r.style.cssText=`
    position: fixed; bottom: 80px; left: 50%; transform: translateX(-50%);
    background: ${t?`#ef4444`:`#1e1e2e`}; color: white;
    padding: 10px 18px; border-radius: 999px; font-size: 13px;
    font-family: sans-serif; z-index: 99999; box-shadow: 0 4px 20px rgba(0,0,0,0.3);
    display: flex; align-items: center; gap: 8px;
  `,r.innerHTML=e,document.body.appendChild(r),setTimeout(()=>r.remove(),4e3)}function i(e){let t=document.getElementById(`contextsnap-modal`);t&&t.remove();let n=document.createElement(`div`);n.id=`contextsnap-modal`,n.style.cssText=`
    position: fixed; inset: 0; background: rgba(0,0,0,0.5);
    z-index: 99999; display: flex; align-items: center; justify-content: center;
  `;let r=document.createElement(`div`);r.style.cssText=`
    background: #1e1e2e; color: white; border-radius: 16px;
    padding: 20px; width: 480px; max-width: 90vw; max-height: 70vh;
    display: flex; flex-direction: column; gap: 12px;
    box-shadow: 0 8px 40px rgba(0,0,0,0.5); font-family: sans-serif;
  `;let i=document.createElement(`div`);i.style.cssText=`display: flex; justify-content: space-between; align-items: center;`,i.innerHTML=`
    <span style="font-weight: 700; font-size: 15px;">🧠 ContextSnap — Gemini</span>
    <button id="contextsnap-close" style="background:none;border:none;color:white;font-size:18px;cursor:pointer;">✕</button>
  `;let a=document.createElement(`textarea`);a.value=e,a.readOnly=!0,a.style.cssText=`
    background: #2a2a3e; color: #e2e8f0; border: 1px solid #4a4a6a;
    border-radius: 8px; padding: 10px; font-size: 12px; line-height: 1.6;
    resize: none; flex: 1; min-height: 200px; font-family: sans-serif;
    outline: none;
  `;let o=document.createElement(`button`);o.innerHTML=`📋 Copy to Clipboard`,o.style.cssText=`
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    color: white; border: none; border-radius: 999px;
    padding: 10px 20px; font-size: 13px; font-weight: 600;
    cursor: pointer; width: 100%;
  `,o.addEventListener(`click`,()=>{navigator.clipboard.writeText(e),o.innerHTML=`✅ Copied!`,setTimeout(()=>o.innerHTML=`📋 Copy to Clipboard`,2e3)}),r.appendChild(i),r.appendChild(a),r.appendChild(o),n.appendChild(r),document.body.appendChild(n),document.getElementById(`contextsnap-close`).addEventListener(`click`,()=>n.remove()),n.addEventListener(`click`,e=>{e.target===n&&n.remove()})}function a(){if(document.getElementById(`contextsnap-btn`))return;let a=document.querySelector(`.ql-editor[contenteditable="true"]`);if(!a)return;let o=a.parentElement?.parentElement?.parentElement?.parentElement?.parentElement?.parentElement;if(!o)return;let s=o.querySelector(`.leading-actions-wrapper`);if(!s)return;let c=document.createElement(`button`);c.id=`contextsnap-btn`,c.title=`ContextSnap — Capture & Summarize`,c.style.cssText=`
    display: inline-flex; align-items: center; gap: 5px;
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    color: white; border: none; border-radius: 999px;
    padding: 5px 12px; font-size: 12px; font-weight: 600;
    cursor: pointer; z-index: 9999; margin: 0 4px;
    font-family: sans-serif; white-space: nowrap;
    box-shadow: 0 2px 8px rgba(99,102,241,0.4);
    transition: opacity 0.2s;
  `,c.innerHTML=`🧠 Snap`,c.addEventListener(`mouseenter`,()=>c.style.opacity=`0.85`),c.addEventListener(`mouseleave`,()=>c.style.opacity=`1`),c.addEventListener(`click`,async()=>{c.innerHTML=`⏳ Capturing...`,c.disabled=!0;let a=e();if(a.length===0){r(`❌ No messages found`,!0),c.innerHTML=`🧠 Snap`,c.disabled=!1;return}let o=t(a);chrome.storage.local.get([`geminiApiKey`],async e=>{let t=e.geminiApiKey;if(!t){i(`[CONTEXT RESUME]\n\nContinue from our previous conversation:\n\n${o}\n\nPlease acknowledge and continue.`),c.innerHTML=`🧠 Snap`,c.disabled=!1;return}c.innerHTML=`✨ Summarizing...`;try{let e=await n(t,o);e?i(`[CONTEXT RESUME — AI Summary]\n\nContinue from our previous conversation. Here's what we discussed:\n\n${e}\n\nPlease acknowledge and continue.`):r(`❌ Summarization failed`,!0)}catch(e){r(`❌ Error: `+e.message,!0)}c.innerHTML=`🧠 Snap`,c.disabled=!1})}),s.appendChild(c)}new MutationObserver(()=>a()).observe(document.body,{childList:!0,subtree:!0}),a(),chrome.runtime.onMessage.addListener((t,n,r)=>{if(t.action===`CAPTURE_CONTEXT`){let t=e();t.length===0?r({success:!1}):r({success:!0,messages:t,source:`gemini`})}return!0});